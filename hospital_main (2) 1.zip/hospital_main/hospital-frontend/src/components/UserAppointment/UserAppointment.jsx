import UserAppointMentCard from "../Card/UserAppointMentCard";
import { useAppContext } from "../../context/AppContext";

const UserAppointment = () => {
  const { state } = useAppContext();

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-9 my-20">
      {state.allAppionments.map((item) => (
        <UserAppointMentCard key={item._id} data={item} />
      ))}
    </div>
  );
};

export default UserAppointment;
