import { useEffect, useState } from "react";
import AppointMentCard from "../Card/AppointMentCard";
import axios from "axios";
import { useAppContext } from "../../context/AppContext";
import UserAppointMentCard from "../Card/UserAppointMentCard";

const Home = () => {
  const { state, dispatch } = useAppContext();

  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  useEffect(() => {
    fetchAppoinments().then((data) =>
      dispatch({ type: "FETACH_APPOINMENTS", payload: data?.data?.data })
    );
  }, [dispatch]);

  const fetchAppoinments = async () => {
    const token = localStorage.getItem("doctor-token");
    return await axios.get("http://localhost:5000/api/v1/appoinments", {
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json",
      },
    });
  };
  console.log(from, to);

  return (
    <div>
      <div className="my-10 flex gap-12">
        <div className="">
          <label>From : </label>
          <input
            type="date"
            name=""
            id=""
            className="border p-4"
            value={from}
            onChange={(e) => setFrom(e.target.value)}
          />
        </div>
        <div className="">
          <label>To : </label>
          <input
            type="date"
            name=""
            id=""
            value={to}
            className="border p-4"
            onChange={(e) => setTo(e.target.value)}
          />
        </div>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-2 2xl:grid-cols-3 gap-9 mb-20">
        {from !== "" && to !== "" && state?.allAppionments?.length ? (
          state?.allAppionments.filter((ap) => ap.date >= from && ap.date <= to)
            ?.length ? (
            state?.allAppionments
              .filter((ap) => ap.date >= from && ap.date <= to)
              .map((item) =>
                state?.user?.role === "user" ? (
                  <AppointMentCard key={item._id} appoinment={item} />
                ) : (
                  <UserAppointMentCard key={item._id} data={item} />
                )
              )
          ) : (
            <p className="text-xl">
              No Appointment Found between {from} to {to}
            </p>
          )
        ) : (from === "" || to === "") && state?.allAppionments?.length ? (
          state?.allAppionments.map((item) =>
            state?.user?.role === "user" ? (
              <AppointMentCard key={item._id} appoinment={item} />
            ) : (
              <UserAppointMentCard key={item._id} data={item} />
            )
          )
        ) : (
          <p className="text-xl">No Appointment Found!</p>
        )}
      </div>
    </div>
  );
};

export default Home;
