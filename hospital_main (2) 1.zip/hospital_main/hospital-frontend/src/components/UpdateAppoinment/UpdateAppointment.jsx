/* eslint-disable react/prop-types */
import axios from "axios";
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import { useAppContext } from "../../context/AppContext";

const UpdateAppointment = ({ data, setOpen }) => {
  const [formData, setFromData] = useState(data);
  const navigate = useNavigate();
  const { state, dispatch } = useAppContext();

  const handleOnChange = (e) => {
    setFromData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const handleUpdate = async (e) => {
    e.preventDefault();
    try {
      const token = localStorage.getItem("doctor-token");
      await axios.patch(
        `http://localhost:5000/api/v1/appoinments/${data._id}`,
        formData,
        {
          headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "application/json",
          },
        }
      );
      const updateAppoints = state.allAppionments.map((item) => {
        if (item._id === data._id) {
          item = formData;
        }
        return item;
      });
      dispatch({ type: "UPDATED_APPIONTMENT", payload: updateAppoints });
      toast.success("Appointment created");
      navigate("/");
    } catch (error) {
      toast.error("Somthing went to wrong");
    }
  };

  return (
    <div className="w-full mx-auto  p-12 bg-white rounded-2xl  ">
      <p className="font-bold text-2xl mb-10 text-center">
        Update Appointments
      </p>
      <form onSubmit={handleUpdate}>
        <div className="flex flex-col">
          <div className="flex flex-col">
            <label className="mb-3">Name</label>
            <input
              onChange={handleOnChange}
              className="text-base px-4 py-2 border  border-gray-300 rounded-lg focus:outline-none focus:border-blue-400 w-full md:w-[350px]"
              type="text"
              name="name"
              value={formData.name}
            />
          </div>
          <div className="flex flex-col">
            <label className="mb-3">Email</label>
            <input
              onChange={handleOnChange}
              className="text-base px-4 py-2 border  border-gray-300 rounded-lg focus:outline-none focus:border-blue-400 w-full md:w-[350px]"
              type="email"
              name="email"
              value={formData.email}
            />
          </div>
        </div>
        <div className="flex flex-col my-5">
          <div className="flex flex-col">
            <label className="mb-3">Gender</label>
            <select
              onChange={handleOnChange}
              name="gender"
              className="text-base px-4 py-2 border  border-gray-300 rounded-lg focus:outline-none focus:border-blue-400 w-full md:w-[350px]"
              defaultValue={"male"}
            >
              <option value="male">Male</option>
              <option value="female">Female</option>
              <option value="transgender">Transgender</option>
              <option value="non_confirming">Non-binary/non-conforming</option>
              <option value="not_respond">Prefer not to respond.</option>
            </select>
          </div>
          <div className="flex flex-col">
            <label className="mb-3">Reason</label>
            <input
              onChange={handleOnChange}
              className="text-base px-4 py-2 border  border-gray-300 rounded-lg focus:outline-none focus:border-blue-400 w-full md:w-[350px]"
              type="text"
              name="reason"
              value={formData.reason}
            />
          </div>
        </div>
        <div className="flex flex-col">
          <div className="flex flex-col">
            <label className="mb-3">Doctor Name</label>
            <input
              onChange={handleOnChange}
              className="text-base px-4 py-2 border  border-gray-300 rounded-lg focus:outline-none focus:border-blue-400 w-full md:w-[350px]"
              type="text"
              name="doctor_name"
              value={formData.doctor_name}
            />
          </div>
          <div className="flex flex-col">
            <label className="mb-3">Date</label>
            <input
              onChange={handleOnChange}
              className="text-base px-4 py-2 border  border-gray-300 rounded-lg focus:outline-none focus:border-blue-400 w-full md:w-[350px]"
              type="date"
              name="date"
              placeholder="MM/DD/YYYY"
              value={formData.date}
            />
          </div>
        </div>
        <div className="flex justify-center items-center mt-20 gap-4">
          <button
            onClick={() => setOpen(false)}
            className="bg-[#275CE3CC] text-white rounded-lg w-40 py-3"
          >
            Update
          </button>
          <button
            // type="button"
            className="mt-3 inline-flexjustify-center  bg-white   text-sm font-semibold text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 hover:bg-gray-50 sm:mt-0 sm:w-auto rounded-lg w-40 py-3 px-8"
            onClick={() => setOpen(false)}
            // ref={cancelButtonRef}
          >
            Cancel
          </button>
        </div>
      </form>
    </div>
  );
};

export default UpdateAppointment;
