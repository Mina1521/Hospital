import { SiGmail } from "react-icons/si";
import { FaGithub } from "react-icons/fa6";
import { useContext } from "react";
import { AuthContext } from "../../context/authProvider1";
import { useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import { useAppContext } from "../../context/AppContext";
import axios from "axios";

const SocialAuth = () => {
  const { signInWithGoogle, signInWithGithub } = useContext(AuthContext);
  const navigate = useNavigate();

  const { dispatch } = useAppContext();

  const handleGoogleSignin = () => {
    signInWithGoogle()
      .then(async (res) => {
        const user = {
          name: res?.user.displayName,
          email: res?.user.email,
        };

        const result = await axios.post(
          "http://localhost:5000/api/v1/user/socialLogin",
          user
        );
        localStorage.setItem("doctor-token", result?.data?.data.accessToken);
        dispatch({
          type: "AUTH_USER_SET",
          payload: result?.data?.data.user,
        });
        toast.success("Login Successfull");
        navigate("/");
      })
      .catch((err) => console.log(err));
  };

  const handleGithubSignin = () => {
    signInWithGithub()
      .then(async (res) => {
        const user = {
          name: res?.user.displayName,
          email: res?.user.email,
        };
        const result = await axios.post(
          "http://localhost:5000/api/v1/user/socialLogin",
          user
        );
        localStorage.setItem("doctor-token", result?.data?.data.accessToken);
        dispatch({
          type: "AUTH_USER_SET",
          payload: result?.data?.data.user,
        });
        toast.success("Login Successfull");
        navigate("/");
      })
      .catch(() => {
        toast.error("Bad Credential");
      });
  };

  return (
    <>
      <div className="w-full flex justify-center gap-5">
        <div className="mb-2 text-[35px] cursor-pointer">
          <SiGmail onClick={handleGoogleSignin} className="text-red-400" />
        </div>

        <div className="mb-2 text-[35px] cursor-pointer">
          <FaGithub onClick={handleGithubSignin} className="text-red-400" />
        </div>
      </div>
    </>
  );
};

export default SocialAuth;
