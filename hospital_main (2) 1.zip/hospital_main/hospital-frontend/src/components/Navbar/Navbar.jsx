import { useNavigate } from "react-router-dom";
import { useAppContext } from "../../context/AppContext";
import { toast } from "react-toastify";

const Navbar = () => {
  const navigate = useNavigate();
  const { state, dispatch } = useAppContext();

  const handleLogout = () => {
    localStorage.removeItem("doctor-token");
    dispatch({ type: "REMOVE_STATE" });
    toast.success("Logout Successfull");
    navigate("/signin");
  };
  console.log(state);
  return (
    <div className="md:flex md:justify-between md:items-center my-5">
      <p
        onClick={() => navigate("/")}
        className="text-center md:text-start cursor-pointer font-bold text-black text-[24px] "
      >
        Appointment Tracker
      </p>
      <div className="flex justify-between gap-3 items-center mt-5 md:mt-0">
        {state?.user?.role === "admin" && (
          <p
            onClick={() => navigate("/create/appointment")}
            className="cursor-pointer font-bold text-black text-[20px] "
          >
            Add New
          </p>
        )}
        {!state.user ? (
          <>
            <p
              onClick={() => navigate("/signin")}
              className="cursor-pointer font-bold text-black text-[20px] mx-10"
            >
              Login
            </p>
            <p
              onClick={() => navigate("/signup")}
              className="cursor-pointer font-bold text-black text-[20px] "
            >
              Signup
            </p>
          </>
        ) : (
          <p
            onClick={handleLogout}
            className="cursor-pointer font-bold text-black text-[20px] "
          >
            Logout
          </p>
        )}
      </div>
    </div>
  );
};

export default Navbar;
