import axios from "axios";
import { toast } from "react-toastify";
import UpdateModal from "../modal/updateModal";
import { useRef, useState } from "react";
import { useAppContext } from "../../context/AppContext";

/* eslint-disable react/prop-types */
const UserAppointMentCard = ({ data }) => {
  const [open, setOpen] = useState(false);
  const cancelButtonRef = useRef(null);

  const { state, dispatch } = useAppContext();

  const handleDelete = async () => {
    const token = localStorage.getItem("doctor-token");
    try {
      const response = await axios.delete(
        `http://localhost:5000/api/v1/appoinments/${data._id}`,
        {
          headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "application/json",
          },
        }
      );
      const filerAppointment = state.allAppionments.filter(
        (item) => item._id !== data._id
      );

      dispatch({ type: "DELETE_APPOINTMENT", payload: filerAppointment });
      if (response?.data?.status === 200) {
        toast.success("Deleted Successfull");
      }
    } catch (err) {
      toast.error(err?.response?.data?.message);
    }
  };

  const handleUpdate = () => {
    setOpen(true);
  };

  return (
    <div className=" bg-[#fffdfd] rounded-[20px] border p-5 border-solid border-[#b3b3b3] relative">
      <div className="flex items-center">
        <div className="w-[83px] h-[83px] bg-[#d9d9d93d] rounded-[41.5px/41.59px] border border-solid border-[#0079ab] mr-5 flex">
          <img
            className="w-[95%] m-auto h-[95%] overflow-hidden rounded-full"
            src="https://images.pexels.com/photos/3991782/pexels-photo-3991782.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
            alt=""
          />
        </div>
        <div>
          <h2 className="font-bold text-2xl">{data.name}</h2>
          <p className="mt-1">{data.date}</p>
        </div>
      </div>
      <div className="mt-5">
        <p>Patient Name : {data.name}</p>
        <p>Doctor Name : {data.doctor_name}</p>
        <p>email: {data.email}</p>
        <p>Gender: {data.gender}</p>
        <p>Reason: {data.reason}</p>
        <p>Date: {data.date}</p>
      </div>
      <div className="flex justify-between items-center mt-5 gap-5">
        <button
          onClick={() => handleUpdate(data._id)}
          className="bg-[#275CE3CC] text-white rounded-lg w-40 py-2"
        >
          Update
        </button>
        <button
          onClick={handleDelete}
          className="bg-[#E32727CC] text-white rounded-lg w-40 py-2"
        >
          Delete
        </button>
      </div>
      <UpdateModal
        data={data}
        open={open}
        setOpen={setOpen}
        cancelButtonRef={cancelButtonRef}
      />
    </div>
  );
};

export default UserAppointMentCard;
