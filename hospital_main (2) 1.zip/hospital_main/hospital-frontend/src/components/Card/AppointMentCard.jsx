/* eslint-disable react/prop-types */
// eslint-disable-next-line react/prop-types
const AppointMentCard = ({ appoinment }) => {
  return (
    <div className=" bg-[#fffdfd] rounded-[20px] border p-5 border-solid border-[#b3b3b3] relative">
      <div className="flex items-center">
        <div className="w-[83px] h-[83px] bg-[#d9d9d93d] rounded-[41.5px/41.59px] border border-solid border-[#0079ab] mr-5 flex">
          <img
            className="w-[95%] m-auto h-[95%] overflow-hidden rounded-full"
            src="https://images.pexels.com/photos/3991782/pexels-photo-3991782.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
            alt=""
          />
        </div>
        <div>
          <h2 className="font-bold text-2xl">
            {appoinment?.name.toUpperCase()}
          </h2>
          <p className="mt-1">{appoinment?.date}</p>
        </div>
      </div>
      <div className="mt-5">
        <p>Patient Name: {appoinment?.name}</p>
        <p>Patient Eamil: {appoinment?.email}</p>
        <p>Reason: {appoinment?.reason}</p>
        <p>Gender: {appoinment?.gender}</p>
        <p>Doctor Name: {appoinment?.doctor_name}</p>
      </div>
    </div>
  );
};

export default AppointMentCard;
