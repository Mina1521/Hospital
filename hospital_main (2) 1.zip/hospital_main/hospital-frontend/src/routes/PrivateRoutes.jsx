import { Navigate } from "react-router-dom";

// eslint-disable-next-line react/prop-types
const PrivateRoute = ({ children }) => {
  const t = localStorage.getItem("doctor-token");

  return !t ? (
    <Navigate to={{ pathname: "/signin", state: { from: location } }} />
  ) : (
    children
  );
};

export default PrivateRoute;
