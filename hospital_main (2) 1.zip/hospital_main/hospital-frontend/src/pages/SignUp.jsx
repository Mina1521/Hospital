import { useContext, useState } from "react";
import { useNavigate } from "react-router-dom";
import { AuthContext } from "../context/authProvider1";
import { toast } from "react-toastify";
import SocialAuth from "../components/SocialAuth/SocialAuth";
import axios from "axios";
import { useAppContext } from "../context/AppContext";
import { updateProfile } from "firebase/auth";

export default function SignUp() {
  const navigate = useNavigate();

  const { createUser } = useContext(AuthContext);
  const { dispatch } = useAppContext();

  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    email: "",
    password: "",
    confirmPassword: "",
  });

  const handleRegister = async (e) => {
    e.preventDefault();
    const fullName = formData.firstName + " " + formData.lastName;
    createUser(formData.email, formData.password)
      .then(async (result) => {
        const loggedUser = result.user;
        updateProfile(loggedUser, {
          displayName: fullName,
        });
        const newUser = {
          name: fullName,
          email: formData.email,
          password: formData.password,
        };

        const res = await axios.post(
          "http://localhost:5000/api/v1/user/register",
          newUser
        );
        localStorage.setItem("doctor-token", res?.data?.data.accessToken);
        dispatch({ type: "AUTH_USER_SET", payload: res?.data?.data.user });
        toast.success("Register Successfull");
        navigate("/");
      })
      .catch(() => {
        toast.error("Cradintial Error");
      });
  };

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };
  return (
    <div className="flex items-center h-screen">
      <div className="p-6 bg-white mx-auto rounded-2xl w-full sm:w-3/4 md:w-[60%] lg:w-[45%] shadow-xl ">
        <div className="mb-4 text-center">
          <h3 className="font-semibold text-2xl text-gray-800">Sign Up </h3>
          <p className="text-gray-400 mt-2">
            Please sign up your account here.
          </p>
        </div>
        <form
          onSubmit={handleRegister}
          className="px-8 pt-6 pb-8  bg-white rounded"
        >
          <div className="mb-4 md:flex md:justify-between md:gap-4 space-y-2 md:space-y-0">
            <div className="space-y-2">
              <label className="text-sm font-medium text-gray-700 tracking-wide">
                First Name
              </label>
              <input
                onChange={handleChange}
                className=" w-full text-sm px-4 py-2 border  border-gray-300 rounded-lg focus:outline-none focus:border-blue-400"
                type="text"
                name="firstName"
                placeholder="Your First Name"
                value={formData.firstName}
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium text-gray-700 tracking-wide">
                Last Name
              </label>
              <input
                onChange={handleChange}
                className=" w-full text-sm px-4 py-2 border  border-gray-300 rounded-lg focus:outline-none focus:border-blue-400"
                type="text"
                name="lastName"
                placeholder="Your Last Name"
                value={formData.lastName}
              />
            </div>
          </div>
          <div className="space-y-2 mb-4">
            <label className="text-sm font-medium text-gray-700 tracking-wide">
              Email
            </label>
            <input
              onChange={handleChange}
              className=" w-full text-sm px-4 py-2 border  border-gray-300 rounded-lg focus:outline-none focus:border-blue-400"
              type="email"
              name="email"
              placeholder="john@gmail.com"
              value={formData.email}
            />
          </div>
          <div className="mb-8 md:flex md:justify-between md:gap-4 space-y-2 md:space-y-0">
            <div className="space-y-2 w-full md:w-2/4 ">
              <label className="mb-5 text-sm font-medium text-gray-700 tracking-wide">
                Password
              </label>
              <input
                onChange={handleChange}
                name="password"
                className="w-full content-center text-sm px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-400"
                type="password"
                placeholder="Enter your password"
                value={formData.password}
              />
            </div>
            <div className="space-y-2 w-full md:w-2/4">
              <label className="mb-5  text-sm font-medium text-gray-700 tracking-wide">
                Confirm Password
              </label>
              <input
                onChange={handleChange}
                name="confirmPassword"
                className="w-full content-center text-sm px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-400"
                type="password"
                placeholder="Enter your password"
                value={formData.confirmPassword}
              />
            </div>
          </div>
          <div className="mb-6 text-center">
            <button
              className="w-full px-4 py-2 font-bold text-white bg-blue-400 rounded-full hover:bg-blue-500 focus:outline-none focus:shadow-outline"
              type="submit"
            >
              Sign Up
            </button>
          </div>
          <SocialAuth />
          <hr className="mb-6 border-t" />
          <div className="text-lg">
            <a
              className="inline-block text-sm text-blue-500 align-baseline hover:text-blue-800"
              href="./index.html"
            >
              Already have an account?{" "}
              <span className="underline">Sign In</span>
            </a>
          </div>
        </form>
      </div>
    </div>
  );
}
