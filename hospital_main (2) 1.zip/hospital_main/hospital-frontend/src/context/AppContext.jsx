import { createContext, useContext, useReducer } from "react";

const AppContext = createContext();

const initialState = {
  user: null,
  allAppionments: [],
};

const reducer = (state, action) => {
  switch (action.type) {
    case "FETACH_APPOINMENTS":
      return {
        ...state,
        allAppionments: [...action.payload],
      };
    case "ADD_APPOINMENTS":
      return {
        ...state,
        allAppionments: [...state.allAppionments, action.payload],
      };
    case "DELETE_USER_APPOINTMENTS":
      console.log(action.payload);
      return {
        ...state,
        allAppionments: [...action.payload],
      };
    case "AUTH_USER_SET":
      return {
        ...state,
        user: action.payload,
      };
    case "UPDATED_APPIONTMENT":
      return {
        ...state,
        allAppionments: action.payload,
      };
    case "REMOVE_STATE":
      return {
        user: null,
        allAppionments: [],
      };
    case "DELETE_APPOINTMENT":
      return {
        ...state,
        allAppionments: action.payload,
      };
    default:
      return state;
  }
};

export const useAppContext = () => {
  return useContext(AppContext);
};

// eslint-disable-next-line react/prop-types
export const AppProvider = ({ children }) => {
  const [state, dispatch] = useReducer(reducer, initialState);

  return (
    <AppContext.Provider value={{ state, dispatch }}>
      {children}
    </AppContext.Provider>
  );
};
