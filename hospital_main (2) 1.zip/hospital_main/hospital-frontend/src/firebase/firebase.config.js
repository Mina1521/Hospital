import { initializeApp } from "firebase/app";

const firebaseConfig = {
  apiKey: "AIzaSyDoCTUSRlFl73rdvigk1hdbrIKHvp7UuOY",
  authDomain: "docapp-1b888.firebaseapp.com",
  projectId: "docapp-1b888",
  storageBucket: "docapp-1b888.appspot.com",
  messagingSenderId: "873658310903",
  appId: "1:873658310903:web:d436e26159da483fad33f2",
};

const app = initializeApp(firebaseConfig);
export default app;
