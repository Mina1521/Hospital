import { Route, Routes, useNavigate } from "react-router-dom";
import CreateAppointment from "./components/CreateAppointment/CreateAppointment";
import Home from "./components/Home/Home";
import Navbar from "./components/Navbar/Navbar";
// import UserAppointment from "./components/UserAppointment/UserAppointment";
import SignIn from "./pages/SignIn";
import SignUp from "./pages/SignUp";
import PrivateRoute from "./routes/PrivateRoutes";
import { useEffect } from "react";
import { decodedToken } from "./utils";
import { useAppContext } from "./context/AppContext";
import { ToastContainer } from "react-toastify";

function App() {
  const navigate = useNavigate();
  const { dispatch } = useAppContext();
  useEffect(() => {
    const token = localStorage.getItem("doctor-token");
    if (token) {
      const user = decodedToken(token);
      dispatch({ type: "AUTH_USER_SET", payload: user });
      navigate("/");
    }
  }, []);
  return (
    <div className="bg-white px-5 xl:px-20">
      <ToastContainer />
      <Navbar />
      <Routes>
        <Route
          path="/"
          element={
            <PrivateRoute>
              <Home />
            </PrivateRoute>
          }
        />
        <Route path="/signin" element={<SignIn />} />
        <Route path="/signup" element={<SignUp />} />
        {/* <Route
          path="/user/appointment"
          element={
            <PrivateRoute>
              <UserAppointment />
            </PrivateRoute>
          }
        /> */}
        <Route
          path="/create/appointment"
          element={
            <PrivateRoute>
              <CreateAppointment />
            </PrivateRoute>
          }
        />
      </Routes>
    </div>
  );
}

export default App;
