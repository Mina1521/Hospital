import React from "react";
import ReactDOM from "react-dom/client";
import App from "./App.jsx";
import "./index.css";
import { BrowserRouter } from "react-router-dom";
import { AppProvider } from "./context/AppContext.jsx";
import "react-toastify/dist/ReactToastify.css";
import AuthProviders from "./context/authProvider1.jsx";

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <AppProvider>
      <AuthProviders>
        <BrowserRouter>
          <App />
        </BrowserRouter>
      </AuthProviders>
    </AppProvider>
  </React.StrictMode>
);
