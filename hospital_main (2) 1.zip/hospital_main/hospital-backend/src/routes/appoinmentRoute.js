const express = require("express");
// define all appointment specific routes
const {
  createAppoinment,
  getAllAppionments,
  finduserAppoinments,
  updateAppointment,
  deleteAppointment,
} = require("../controllers/appoinmentController");
const checkLogin = require("../middleware/checkLogin");
const router = express.Router();

router.post("/appoinments", checkLogin, createAppoinment);
router.get("/appoinments", checkLogin, getAllAppionments);
// router.get("/user/appoinments", finduserAppoinments);
router.patch("/appoinments/:id", checkLogin, updateAppointment);
router.delete("/appoinments/:id", checkLogin, deleteAppointment);

// export module
module.exports = router;
