const express = require("express");
// define all user related routes
const {
  registerUser,
  loginUser,
  socialLogin,
} = require("../controllers/userController");
const checkLogin = require("../middleware/checkLogin");
const router = express.Router();

router.post("/register", registerUser);
router.post("/login", loginUser);
router.post("/socialLogin", socialLogin);

// export module
module.exports = router;
