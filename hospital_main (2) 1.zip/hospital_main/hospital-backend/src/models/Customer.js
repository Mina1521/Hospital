const mongoose = require("mongoose");
// create customer schema model
const CustomerSchema = new mongoose.Schema(
  {
    customer_name: {
      type: String,
      required: true,
    },
    email: {
      type: String,
      required: false,
    },
    phone: {
      type: String || Number,
      required: true,
    },
    date: {
      type: String,
      required: true,
    },
    status: {
      type: String,
      required: true,
    },
  },
  {
    timestamps: true,
  }
);

const Customer = mongoose.model("Customers", CustomerSchema);

// export module
module.exports = Customer;
