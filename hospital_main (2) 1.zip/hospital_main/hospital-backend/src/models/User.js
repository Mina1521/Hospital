const mongoose = require("mongoose");
// create user schema model
const UserSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: true,
    },
    email: {
      type: String,
      required: true,
      unique: true,
    },
    password: {
      type: String,
    },
    role: {
      type: String,
      enum: ["user", "admin"],
      default: "user",
    },
    // thumbNail: {
    //   type: String,
    //   required: false,
    //   // required: true,
    //   trim: true,
    // },
  },
  {
    timestamps: true,
  }
);

const User = mongoose.model("User", UserSchema);
// export module
module.exports = User;
