const { Schema, model } = require("mongoose");
// create appointment model 
const AppoionmentSchema = new Schema(
  {
    // author: {
    //   type: Schema.ObjectId,
    //   ref: "User",
    //   required: true,
    // },
    name: {
      type: String,
      required: true,
    },
    email: {
      type: String,
      required: false,
    },
    gender: {
      type: String,
      required: true,
    },
    reason: {
      type: String,
      required: true,
    },
    doctor_name: {
      type: String,
      required: true,
    },
    date: {
      type: String,
      required: true,
    },
  },
  {
    timestamps: true,
  }
);

const Appoionment = model("Appoinemnt", AppoionmentSchema);
// export module
module.exports = Appoionment;
