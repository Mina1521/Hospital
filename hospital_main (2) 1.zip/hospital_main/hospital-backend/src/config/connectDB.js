const mongoose = require("mongoose");
require("dotenv").config();
const colors = require("colors");
// create connection to mongoDb
const connectDB = async () => {
  // set strict query to false
  mongoose.set("strict", false);

  try {
    await mongoose.connect(process.env.MONGO_URL, {
      useNewUrlParser: true,
      useUnifiedTopology: true,
    });
  } catch (error) {
    console.error(colors.red("📕", error));
  }
};

// export module
module.exports = connectDB;
