const Appoionment = require("../models/Appoinment");

// Create appointment and save information in mongoDB database
const createAppoinment = async (req, res, _next) => {
  const { name, email, gender, reason, doctor_name, date } = req.body;
  const user = req.user;
  try {
    const appoinment = new Appoionment({
      author: user.id,
      name,
      email,
      gender,
      reason,
      doctor_name,
      date,
    });

    // Attempt to save appointment in mongoDB database and alert user if successful, otherwise alert user that action has failed
    const newAppoinment = await appoinment.save();
    res.status(201).json({
      message: "Appoinment created successfully",
      data: newAppoinment,
    });
  } catch (err) {
    return res.status(403).json({
      errorMessage: "There was an error creating Appoinment",
      error: err.message,
    });
  }
};

// Retrieve all appointments from MongoDB database
const getAllAppionments = async (req, res, _next) => {

  // Attempt retrieving all appointments from MongoDb and alert user if action is successful, otherwise alert user that action has failed
  try {
    const allAppoinments = await Appoionment.find({});

    res.status(200).json({
      message: "All Appoinments",
      data: allAppoinments,
    });
  } catch (err) {
    return res.status(403).json({
      errorMessage: "There was a to Create Appoinment",
      error: err.message,
    });
  }
};

// Update existing appointment in MongoDB database
const updateAppointment = async (req, res, _next) => {
  const { id } = req.params;
  const user = req.user;
  // Try to find appointment which user has selected in mongoDB database
  try {
    const appoinment = await Appoionment.findById(id);
    if (!appoinment) {
      return res.status(400).json({
        status: 400,
        message: "Bad Request",
      });
    }
    // Check if user is admin and then attempt updating selected appointment in MongoDb and alert user if action is successful, otherwise alert user that action has failed
    if (user.role === "admin") {
      const name = req.body.name ?? appoinment.name;
      const email = req.body.email ?? appoinment.email;
      const gender = req.body.gender ?? appoinment.gender;
      const reason = req.body.reason ?? appoinment.reason;
      const doctor_name = req.body.doctor_name ?? appoinment.doctor_name;
      const date = req.body.date ?? appoinment.date;

      appoinment.name = name;
      appoinment.email = email;
      appoinment.gender = gender;
      appoinment.reason = reason;
      appoinment.doctor_name = doctor_name;
      appoinment.date = date;

      await appoinment.save();
      // Return success message if update is successful
      return res.status(200).json({
        code: 200,
        message: "Updated Appointment",
      });
    } else {
      // Return error message if user is not administrator
      return res.status(401).json({
        status: 403,
        errorMessage: "Permission denied",
        error: err.message,
      });
    }
  } catch (err) {
    return res.status(403).json({
      errorMessage: "There was a to Create Appoinment",
      error: err.message,
    });
  }
};

// Delete existing appointment in MongoDB database
const deleteAppointment = async (req, res, _next) => {
  const { id } = req.params;
  const user = req.user;
  try {
    // Check if user is administrator
    if (user.role === "admin") {
      // find appointment in database and remove
      await Appoionment.findByIdAndDelete(id);
      // return success message if action is successful
      return res.status(200).json({
        status: 200,
        message: "Deleted Succssfully",
      });
    } else {
      // return error message if user is not administrator
      throw new Error("Permission Denied");
    }
  } catch (err) {
    console.log(err);
    return res.status(err.status || 500).json({
      status: err.status || 500,
      message: err.message || "Somgthing went to wrong",
    });
  }
};

// const finduserAppoinments = async (_req, res, _next) => {
//   const user = {
//     email: "programmer.rayhan1@gmail.com",
//   };
//   try {
//     const userAppointments = await Appoionment.find({ email: user.email });

//     res.status(200).json({
//       message: "All Appoinments",
//       data: userAppointments,
//     });
//   } catch (err) {
//     return res.status(403).json({
//       errorMessage: "There was a to Create Appoinment",
//       error: err.message,
//     });
//   }
// };

// export modules
module.exports = {
  createAppoinment,
  getAllAppionments,
  updateAppointment,
  deleteAppointment,
  //   finduserAppoinments,
};
