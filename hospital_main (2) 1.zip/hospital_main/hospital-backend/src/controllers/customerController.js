const Customer = require("../models/Customer");
const { format } = require("date-fns");

// Get all customers from database
const getAllCustomers = async (req, res) => {
  try {
    // do pagination stuff here
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 2;
    const skipIndex = (page - 1) * limit;
    const total = await Customer.countDocuments();
    // get the results from very last page

    const results = await Customer.find()
      .limit(limit)
      .skip(skipIndex)
      .sort({ _id: -1 })
      .exec();

      // return success message
    res.status(200).json({
      message: "All customers",
      data: results,
      total: total,
    });
  } catch (err) {
    // return friendly error message
    res.status(403).json({
      errorMessage: "There was a problem getting the customers",
      error: err.message,
    });
  }
};

// get customers from database by search query
const getCustomersBySearch = async (req, res) => {
  try {
    // do pagination stuff here
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 2;
    const skipIndex = (page - 1) * limit;
    const search = req.query.search;
    const total = await Customer.countDocuments({
      $or: [
        { customer_name: { $regex: search, $options: "i" } },
        { email: { $regex: search, $options: "i" } },
        { phone: { $regex: search, $options: "i" } },
        { date: { $regex: search, $options: "i" } },
        { status: { $regex: search, $options: "i" } },
      ],
    });
    // get the results from very last page

    const results = await Customer.find({
      $or: [
        { customer_name: { $regex: search, $options: "i" } },
        { email: { $regex: search, $options: "i" } },
        { phone: { $regex: search, $options: "i" } },
        { date: { $regex: search, $options: "i" } },
        { status: { $regex: search, $options: "i" } },
      ],
    })
      .limit(limit)
      .skip(skipIndex)
      .sort({ _id: -1 })
      .exec();

    // return success message 
    res.status(200).json({
      message: "All customers",
      data: results,
      total: total,
    });
  } catch (err) {
    // return friendly error message
    res.status(403).json({
      errorMessage: "There was a problem getting the customers",
      error: err.message,
    });
  }
};
// get customers from database without pagination
const getCustomersNoPagination = async (req, res) => {
  try {
    const customers = await Customer.find();
    const total = await Customer.countDocuments();

    // return success message 
    res.status(200).json({
      message: "All customers",
      data: customers,
      total: total,
    });
  } catch (err) {
    // return friendly error message
    res.status(403).json({
      errorMessage: "There was a problem getting the customers",
      error: err.message,
    });
  }
};

// get one customer based on ID from database
const getSingleCustomer = async (req, res) => {
  try {
    const id = req.params.id;
    const customer = await Customer.findById(id);
    // return success message 
    res.status(200).json({
      message: "Customer found",
      data: customer,
    });
  } catch (err) {
    // return friendly error message
    res.status(403).json({
      errorMessage: "There was a problem getting the customer",
      error: err.message,
    });
  }
};

// delete customer from database based on id
const deleteCustomer = async (req, res) => {
  try {
    const id = req.params.id;
    const customer = await Customer.findByIdAndDelete(id);
    // return success message
    res.status(200).json({
      message: "Customer deleted successfully",
      data: customer,
    });
  } catch (error) {
    // return friendly error message
    res.status(403).json({
      errorMessage: "There was a problem deleting the customer",
      error: err.message,
    });
  }
};

// delete multiple customers from database based on a IDs
const deleteMultipleCustomers = async (req, res) => {
  try {
    const ids = req.body.ids;
    const customers = await Customer.deleteMany({ _id: { $in: ids } });
    // return success message
    res.status(200).json({
      message: "Customers deleted successfully",
      data: customers,
    });
  } catch (error) {
    // return friendly error message
    res.status(403).json({
      errorMessage: "There was a problem deleting the customer",
      error: err.message,
    });
  }
};

// Create new customer in database
const createCustomer = async (req, res) => {
  try {
    const authoriztion = req.headers.authorization;
    const customer = new Customer(req.body);
    const newCustomer = await customer.save();
    // return success message
    res.status(201).json({
      message: "Customer created successfully",
      data: newCustomer,
    });
  } catch (err) {
    // return friendly error message
    res.status(403).json({
      errorMessage: "There was a problem creating the customer",
      error: err.message,
    });
  }
};

// Update existing customer in Database
const updateCustomer = async (req, res) => {
  try {
    const id = req.params.id;
    const updates = req.body;
    const options = { new: true };
    const updatedCustomer = await Customer.findByIdAndUpdate(
      id,
      updates,
      options
    );
    // return success message
    res.status(200).json({
      message: "Customer updated successfully",
      data: updatedCustomer,
    });
  } catch (error) {
    // return friendly error message
    res.status(403).json({
      errorMessage: "There was a problem updating the customer",
      error: err.message,
    });
  }
};

// export modules
module.exports = {
  getAllCustomers,
  getCustomersNoPagination,
  deleteCustomer,
  createCustomer,
  deleteMultipleCustomers,
  getSingleCustomer,
  updateCustomer,
  getCustomersBySearch,
};
