# HyperionDev Full Stack Web Development Bootcamp - Level 3 - Task 15 - Capstone Project Part 2: Implementation

## Description

This task involved creating an application that allows doctors to track information about patients and appointments. The requirements for this project were as follows:
- It is built using Express, React, and MongoDB (the MERN stack).
- It creates, reads, updates, and deletes (CRUD) information from MongoDB.
- It has a custom server built using Express.
- It authenticates users using JWT.
- The front-end is built using React. You can use a React framework (e.g. Create React App or Next.js) of your choice.
- The application allows for normal end-user access and admin access. An administrator should be able to monitor and make changes to users’ behaviour.

## Table of Contents

- [Instructions](#instructions)
- [Technologies](#technologies)
- [Installation](#installation)
- [Usage](#usage)

## Instructions

These were the instructions I was given to guide me in this task:

- Create a full-stack web application that meets ALL the criteria listed previously for this Capstone Project.
- Deploy your app. Add the link to your deployed application to the readme.md file of your project.
- Push all the work that you have generated for this project (including the design documentation that you generated in the first part of the project) to GitHub.

### Technologies

This project uses:

- HTML
- CSS
- Javascript
- React
- Node
- Express
- MongoDB
- JWT (JSON Web Tokens)
-ViteJs

## Installation

To run this project, do the following:

1. Copy the project files to a directory called 'hospital_main' on your local machine.
2. Navigate to this directory from the command line interface. E.g. cd c:/hospital_main.
3. Navigate to "/hospital-backend" directory inside "hospital_main". E.g. cd c:/hospital_main/hospital-backend.
4. In the command line interface type 'npm install'.
5. Once it has finished installing, type 'npm start'.
6. Now navigate to the "/hospital-frontend" directory inside "hospital_main". E.g. cd c:/hospital_main/hospital-frontend.
7. In the command line interface, once again type 'npm install'.
8. Once it has finished installing, type 'npm run dev'.
9. You have now started both the backend and frontend servers.
10. Take note of the url shown in the command line interface as this is the url you'd need to use to view the project in your web browser.

## Usage

### Login

1. You will first need to enter your credential in order to sign in 
2. Once you have signed in you can do the below:
- Add new appointment. 
- Check your appointment date.
- Update your appointment.
- Delete your appointment. 
- Logout

### Add New Appointment

3. To add a new appointment
- On the top right-hand side you will notice a button that says ‘Add new’. Click on that button.
- A pop-up page will open where you will require to add your details and choose a doctor.
- Once done click on save.
- That appointment will now show on your Home page.

### Check Existing Appointment

4. To check your appointment for a specific time:
- Under appointment tracker, choose the date and you will be able to see the appointment for that specific time. 

### Update Existing Appointment

5. To update an Appointment:
- Click on update on the appointment you wish to update.
- A pop-up page will appear where you will be required to make your changes once done click on save.

### Delete Existing Appointment

6. To delete an appointment:
- From the appointment you wish to delete, click on delete and the appointment will be deleted

### Logout

7. To logout:
- On the top right-hand side you will notice a button that says ‘Logout. Click on that button.
